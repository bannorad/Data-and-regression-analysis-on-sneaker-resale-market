```python
#Import modules
import pandas as pd
import numpy as np
```


```python
#Reading Sneakers data file
sneakers_data = pd.read_excel("/Users/ghanamanb/Desktop/Sneakers.xlsx")
```


```python
sneakers_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Designer</th>
      <th>Sneaker_Name</th>
      <th>Shoe_Size</th>
      <th>Release_Date</th>
      <th>Retail_Price</th>
      <th>Order_Date</th>
      <th>Year</th>
      <th>Calendar_Quarter</th>
      <th>Order_Period (Q-YYYY)</th>
      <th>Resale_Price</th>
      <th>Buyer_Region</th>
      <th>Hold_Period_In_Days</th>
      <th>Find dash</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adidas</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-Low-V2-Beluga</td>
      <td>11.0</td>
      <td>2016-09-24</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1097</td>
      <td>California</td>
      <td>342</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Adidas</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-V2-Core-Black-Copper</td>
      <td>11.0</td>
      <td>2016-11-23</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>685</td>
      <td>California</td>
      <td>282</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Adidas</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-V2-Core-Black-Green</td>
      <td>11.0</td>
      <td>2016-11-23</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>690</td>
      <td>California</td>
      <td>282</td>
      <td>7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Adidas</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-V2-Core-Black-Red</td>
      <td>11.5</td>
      <td>2016-11-23</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1075</td>
      <td>Kentucky</td>
      <td>282</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Adidas</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-V2-Core-Black-Red-2017</td>
      <td>11.0</td>
      <td>2017-02-11</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>828</td>
      <td>Rhode Island</td>
      <td>202</td>
      <td>7</td>
    </tr>
  </tbody>
</table>
</div>




```python
#How many rows and columns does the dataset have
sneakers_data.shape
```




    (99956, 14)




```python
#What are the data types of each column
sneakers_data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 99956 entries, 0 to 99955
    Data columns (total 14 columns):
     #   Column                 Non-Null Count  Dtype         
    ---  ------                 --------------  -----         
     0   Brand                  99956 non-null  object        
     1   Designer               99956 non-null  object        
     2   Sneaker_Name           99956 non-null  object        
     3   Shoe_Size              99956 non-null  float64       
     4   Release_Date           99956 non-null  datetime64[ns]
     5   Retail_Price           99956 non-null  int64         
     6   Order_Date             99956 non-null  datetime64[ns]
     7   Year                   99956 non-null  int64         
     8   Calendar_Quarter       99956 non-null  object        
     9   Order_Period (Q-YYYY)  99956 non-null  object        
     10  Resale_Price           99956 non-null  int64         
     11  Buyer_Region           99956 non-null  object        
     12  Hold_Period_In_Days    99956 non-null  int64         
     13  Find dash              99956 non-null  int64         
    dtypes: datetime64[ns](2), float64(1), int64(5), object(6)
    memory usage: 10.7+ MB



```python
#Summary statistics
sneakers_data.describe().drop(columns = 'Find dash')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Shoe_Size</th>
      <th>Retail_Price</th>
      <th>Year</th>
      <th>Resale_Price</th>
      <th>Hold_Period_In_Days</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>99956.000000</td>
      <td>99956.00000</td>
      <td>99956.000000</td>
      <td>99956.000000</td>
      <td>99956.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>9.344181</td>
      <td>208.61359</td>
      <td>2018.029013</td>
      <td>446.634719</td>
      <td>183.708722</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.329588</td>
      <td>25.20001</td>
      <td>0.542357</td>
      <td>255.982969</td>
      <td>232.354142</td>
    </tr>
    <tr>
      <th>min</th>
      <td>3.500000</td>
      <td>130.00000</td>
      <td>2017.000000</td>
      <td>186.000000</td>
      <td>-69.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>8.000000</td>
      <td>220.00000</td>
      <td>2018.000000</td>
      <td>275.000000</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>9.500000</td>
      <td>220.00000</td>
      <td>2018.000000</td>
      <td>370.000000</td>
      <td>56.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>11.000000</td>
      <td>220.00000</td>
      <td>2018.000000</td>
      <td>540.000000</td>
      <td>345.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>17.000000</td>
      <td>250.00000</td>
      <td>2019.000000</td>
      <td>4050.000000</td>
      <td>1321.000000</td>
    </tr>
  </tbody>
</table>
</div>



Estimation of location


```python
#Mean
average_shoe_size=sneakers_data["Shoe_Size"].mean()
average_retail_price_usd=sneakers_data["Retail_Price"].mean()
average_resale_price_usd=sneakers_data["Resale_Price"].mean()
print(average_shoe_size)
print(average_retail_price_usd)
print(average_resale_price_usd)
```

    9.344181439833527
    208.613589979591
    446.63471927648163



```python
#Median 
median_shoe_size=sneakers_data["Shoe_Size"].median()
median_retail_price_usd=sneakers_data["Retail_Price"].median()
median_resale_price_usd=sneakers_data["Resale_Price"].median()
print(median_shoe_size)
print(median_retail_price_usd)
print(median_resale_price_usd)
```

    9.5
    220.0
    370.0



```python
#Trimmed mean
from scipy.stats import trim_mean
trim_mean_shoe_size=trim_mean(sneakers_data["Shoe_Size"],0.1)
trim_mean_retail_price_usd=trim_mean(sneakers_data["Retail_Price"],0.1)
trim_mean_resale_price_usd=trim_mean(sneakers_data["Resale_Price"],0.1)
print(trim_mean_shoe_size)
print(trim_mean_retail_price_usd)
print(trim_mean_resale_price_usd)
```

    9.451241777755547
    213.34292074131506
    401.3617787559713


Estimation of variability


```python
#Variance
from statistics import variance
var_shoe_size = variance(sneakers_data["Shoe_Size"])
var_retail_price_usd = variance(sneakers_data["Retail_Price"])
var_resale_price_usd = variance(sneakers_data["Resale_Price"])
print(var_shoe_size)
print(var_retail_price_usd)
print(var_resale_price_usd)
```

    5.426978399533862
    635.0404812102619
    65527.28034485742



```python
# Standard Deviation
from statistics import stdev
stdev_shoe_size = stdev(sneakers_data["Shoe_Size"])
stdev_retail_price_usd = stdev(sneakers_data["Retail_Price"])
stdev_resale_price_usd = stdev(sneakers_data["Resale_Price"])
print(stdev_shoe_size)
print(stdev_retail_price_usd)
print(stdev_resale_price_usd)
```

    2.329587602888945
    25.200009547820848
    255.98296885702655



```python
# Mean Absolute Deviation (MAD)
from numpy import mean, absolute
mad_shoe_size = mean(absolute(sneakers_data["Shoe_Size"]-mean(sneakers_data["Shoe_Size"])))
mad_retail_price_usd = mean(absolute(sneakers_data["Retail_Price"]-mean(sneakers_data["Retail_Price"])))
mad_resale_price_usd = mean(absolute(sneakers_data["Resale_Price"]-mean(sneakers_data["Resale_Price"])))
print(mad_shoe_size)
print(mad_retail_price_usd)
print(mad_resale_price_usd)
```

    1.8540989226981055
    19.1764236923198
    176.8392508599649



```python
# Median Absolute Deviation (MEAD)
from numpy import median, absolute
mead_shoe_size = median(absolute(sneakers_data["Shoe_Size"]-median(sneakers_data["Shoe_Size"])))
mead_retail_price_usd = median(absolute(sneakers_data["Retail_Price"]-median(sneakers_data["Retail_Price"])))
mead_resale_price_usd = median(absolute(sneakers_data["Resale_Price"]-median(sneakers_data["Resale_Price"])))
print(mead_shoe_size)
print(mead_retail_price_usd)
print(mead_resale_price_usd)
```

    1.5
    0.0
    101.0



```python
#Interquartile range
shoe_size_q1 = np.percentile(sneakers_data["Shoe_Size"],25)
shoe_size_q3 = np.percentile(sneakers_data["Shoe_Size"],75)
shoe_size_interquartile_range = shoe_size_q3-shoe_size_q1

retail_price_usd_q1 = np.percentile(sneakers_data["Retail_Price"],25)
retail_price_usd_q3 = np.percentile(sneakers_data["Retail_Price"],75)
retail_price_usd_interquartile_range = retail_price_usd_q3-retail_price_usd_q1

resale_price_usd_q1 = np.percentile(sneakers_data["Resale_Price"],25)
resale_price_usd_q3 = np.percentile(sneakers_data["Resale_Price"],75)
resale_price_usd_interquartile_range = resale_price_usd_q3-resale_price_usd_q1

print(shoe_size_interquartile_range)
print(retail_price_usd_interquartile_range)
print(resale_price_usd_interquartile_range)
```

    3.0
    0.0
    265.0


Exploring Data Distribution


```python
sneakers_data.boxplot(column="Shoe_Size")
```




    <AxesSubplot:>




    
![png](output_17_1.png)
    



```python
sneakers_data.boxplot(column="Retail_Price")
```




    <AxesSubplot:>




    
![png](output_18_1.png)
    



```python
sneakers_data.boxplot(column="Resale_Price")
```




    <AxesSubplot:>




    
![png](output_19_1.png)
    



```python
#Histogram Shoe Size
import matplotlib.pyplot as plt
plt.hist(x=sneakers_data["Shoe_Size"], bins = 'auto', color = '#0504aa', alpha=0.7, rwidth=0.85)
plt.show()
```


    
![png](output_20_0.png)
    



```python
#Histogram Retail Price
import matplotlib.pyplot as plt
plt.hist(x=sneakers_data["Retail_Price"], bins = 'auto', color = '#0504aa', alpha=0.7, rwidth=0.85)
plt.show()
```


    
![png](output_21_0.png)
    



```python
#Histogram Resale Price
import matplotlib.pyplot as plt
plt.hist(x=sneakers_data["Resale_Price"], bins = 450, color = '#0504aa', alpha=0.7, rwidth=0.85)
plt.show()
```


    
![png](output_22_0.png)
    



```python
import seaborn as sns
# Violin Plot Shoe Size
sns.violinplot(x=sneakers_data["Shoe_Size"])
```




    <AxesSubplot:xlabel='Shoe_Size'>




    
![png](output_23_1.png)
    



```python
import seaborn as sns
# Violin Plot Retail Price
sns.violinplot(x=sneakers_data["Retail_Price"])
```




    <AxesSubplot:xlabel='Retail_Price'>




    
![png](output_24_1.png)
    



```python
import seaborn as sns
# Violin Plot Retail Price
sns.violinplot(x=sneakers_data["Resale_Price"])
```




    <AxesSubplot:xlabel='Resale_Price'>




    
![png](output_25_1.png)
    





```python
#Correlation Matrix
sneakers_data.drop(columns ='Find dash').corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Shoe_Size</th>
      <th>Retail_Price</th>
      <th>Year</th>
      <th>Resale_Price</th>
      <th>Hold_Period_In_Days</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Shoe_Size</th>
      <td>1.000000</td>
      <td>-0.052798</td>
      <td>-0.061312</td>
      <td>0.082795</td>
      <td>0.017450</td>
    </tr>
    <tr>
      <th>Retail_Price</th>
      <td>-0.052798</td>
      <td>1.000000</td>
      <td>-0.052630</td>
      <td>-0.361550</td>
      <td>0.245391</td>
    </tr>
    <tr>
      <th>Year</th>
      <td>-0.061312</td>
      <td>-0.052630</td>
      <td>1.000000</td>
      <td>-0.127846</td>
      <td>0.138915</td>
    </tr>
    <tr>
      <th>Resale_Price</th>
      <td>0.082795</td>
      <td>-0.361550</td>
      <td>-0.127846</td>
      <td>1.000000</td>
      <td>-0.086407</td>
    </tr>
    <tr>
      <th>Hold_Period_In_Days</th>
      <td>0.017450</td>
      <td>0.245391</td>
      <td>0.138915</td>
      <td>-0.086407</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
nike = sneakers_data[sneakers_data['Designer']=="Off-White"]
nike
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Designer</th>
      <th>Sneaker_Name</th>
      <th>Shoe_Size</th>
      <th>Release_Date</th>
      <th>Retail_Price</th>
      <th>Order_Date</th>
      <th>Year</th>
      <th>Calendar_Quarter</th>
      <th>Order_Period (Q-YYYY)</th>
      <th>Resale_Price</th>
      <th>Buyer_Region</th>
      <th>Hold_Period_In_Days</th>
      <th>Find dash</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>128</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Air-Max-90-Off-White</td>
      <td>8.0</td>
      <td>2017-09-09</td>
      <td>160</td>
      <td>2017-09-07</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1600</td>
      <td>California</td>
      <td>-2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>129</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Air-Max-90-Off-White</td>
      <td>11.5</td>
      <td>2017-09-09</td>
      <td>160</td>
      <td>2017-09-07</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1090</td>
      <td>New York</td>
      <td>-2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>130</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Air-Presto-Off-White</td>
      <td>10.0</td>
      <td>2017-09-09</td>
      <td>160</td>
      <td>2017-09-07</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1344</td>
      <td>New York</td>
      <td>-2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>131</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Air-Presto-Off-White</td>
      <td>10.0</td>
      <td>2017-09-09</td>
      <td>160</td>
      <td>2017-09-07</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1325</td>
      <td>Massachusetts</td>
      <td>-2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>132</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Air-VaporMax-Off-White</td>
      <td>12.0</td>
      <td>2017-09-09</td>
      <td>250</td>
      <td>2017-09-07</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1800</td>
      <td>Kentucky</td>
      <td>-2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>99869</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Zoom-Fly-Off-White-Pink</td>
      <td>11.0</td>
      <td>2018-11-28</td>
      <td>170</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>265</td>
      <td>New York</td>
      <td>77</td>
      <td>5</td>
    </tr>
    <tr>
      <th>99870</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Zoom-Fly-Off-White-Pink</td>
      <td>4.0</td>
      <td>2018-11-28</td>
      <td>170</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>331</td>
      <td>California</td>
      <td>77</td>
      <td>5</td>
    </tr>
    <tr>
      <th>99871</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Zoom-Fly-Off-White-Pink</td>
      <td>6.0</td>
      <td>2018-11-28</td>
      <td>170</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>405</td>
      <td>New York</td>
      <td>77</td>
      <td>5</td>
    </tr>
    <tr>
      <th>99872</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Zoom-Fly-Off-White-Pink</td>
      <td>10.0</td>
      <td>2018-11-28</td>
      <td>170</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>263</td>
      <td>Maryland</td>
      <td>77</td>
      <td>5</td>
    </tr>
    <tr>
      <th>99873</th>
      <td>Nike</td>
      <td>Off-White</td>
      <td>Nike-Zoom-Fly-Off-White-Pink</td>
      <td>9.0</td>
      <td>2018-11-28</td>
      <td>170</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>237</td>
      <td>California</td>
      <td>77</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
<p>27794 rows × 14 columns</p>
</div>




```python
adidas = sneakers_data[sneakers_data['Designer']=="Yeezy"]
adidas
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Designer</th>
      <th>Sneaker_Name</th>
      <th>Shoe_Size</th>
      <th>Release_Date</th>
      <th>Retail_Price</th>
      <th>Order_Date</th>
      <th>Year</th>
      <th>Calendar_Quarter</th>
      <th>Order_Period (Q-YYYY)</th>
      <th>Resale_Price</th>
      <th>Buyer_Region</th>
      <th>Hold_Period_In_Days</th>
      <th>Find dash</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-Low-V2-Beluga</td>
      <td>11.0</td>
      <td>2016-09-24</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1097</td>
      <td>California</td>
      <td>342</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-V2-Core-Black-Copper</td>
      <td>11.0</td>
      <td>2016-11-23</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>685</td>
      <td>California</td>
      <td>282</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-V2-Core-Black-Green</td>
      <td>11.0</td>
      <td>2016-11-23</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>690</td>
      <td>California</td>
      <td>282</td>
      <td>7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-V2-Core-Black-Red</td>
      <td>11.5</td>
      <td>2016-11-23</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>1075</td>
      <td>Kentucky</td>
      <td>282</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>Adidas-Yeezy-Boost-350-V2-Core-Black-Red-2017</td>
      <td>11.0</td>
      <td>2017-02-11</td>
      <td>220</td>
      <td>2017-09-01</td>
      <td>2017</td>
      <td>Q3</td>
      <td>Q3 2017</td>
      <td>828</td>
      <td>Rhode Island</td>
      <td>202</td>
      <td>7</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>99951</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>adidas-Yeezy-Boost-350-V2-Static-Reflective</td>
      <td>8.0</td>
      <td>2018-12-26</td>
      <td>220</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>565</td>
      <td>Oregon</td>
      <td>49</td>
      <td>7</td>
    </tr>
    <tr>
      <th>99952</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>adidas-Yeezy-Boost-350-V2-Static-Reflective</td>
      <td>8.5</td>
      <td>2018-12-26</td>
      <td>220</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>598</td>
      <td>California</td>
      <td>49</td>
      <td>7</td>
    </tr>
    <tr>
      <th>99953</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>adidas-Yeezy-Boost-350-V2-Static-Reflective</td>
      <td>5.5</td>
      <td>2018-12-26</td>
      <td>220</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>605</td>
      <td>New York</td>
      <td>49</td>
      <td>7</td>
    </tr>
    <tr>
      <th>99954</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>adidas-Yeezy-Boost-350-V2-Static-Reflective</td>
      <td>11.0</td>
      <td>2018-12-26</td>
      <td>220</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>650</td>
      <td>California</td>
      <td>49</td>
      <td>7</td>
    </tr>
    <tr>
      <th>99955</th>
      <td>Nike</td>
      <td>Yeezy</td>
      <td>adidas-Yeezy-Boost-350-V2-Static-Reflective</td>
      <td>11.5</td>
      <td>2018-12-26</td>
      <td>220</td>
      <td>2019-02-13</td>
      <td>2019</td>
      <td>Q1</td>
      <td>Q1 2019</td>
      <td>640</td>
      <td>Texas</td>
      <td>49</td>
      <td>7</td>
    </tr>
  </tbody>
</table>
<p>72162 rows × 14 columns</p>
</div>




```python
sns.distplot(nike['Retail_Price'], kde = False, label = 'nike')
sns.distplot(adidas['Retail_Price'], kde = False, label = 'adidas')
plt.legend()
plt.show()
```

    /Users/ghanamanb/opt/anaconda3/lib/python3.8/site-packages/seaborn/distributions.py:2557: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)



    
![png](output_30_1.png)
    



```python
sns.distplot(nike['Resale_Price'], kde = False, label = 'nike')
sns.distplot(adidas['Resale_Price'], kde = False, label = 'adidas')
plt.legend()
plt.show()
```


    
![png](output_31_0.png)
    



```python

```
